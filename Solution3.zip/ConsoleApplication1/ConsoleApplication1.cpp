#include <iostream>
#include "math.hpp"

using namespace std;


int main()
{
    float a, b;
    cin >> a >> b;

   cout << add(a, b) << endl;
   cout << subtract(a, b) << endl;
   cout << multiply(a, b) << endl;
   cout << divide(a, b) << endl;
}