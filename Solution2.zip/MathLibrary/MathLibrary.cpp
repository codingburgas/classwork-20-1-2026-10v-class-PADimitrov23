#include <iostream>
#include "framework.h"
#include "MathLibrary.hpp"

using namespace std;

float trianglePlot(float a, float b, float c) {
	float plot = (a + b + c) / 2.0;
	return plot;
}

float trianglePerimeter(float a, float b, float c) {
	float perimeter = a + b + c;
	return perimeter;
}