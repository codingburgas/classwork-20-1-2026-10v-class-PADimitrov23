#pragma once

float trianglePlot(float a, float b, float c);

float trianglePerimeter(float a, float b, float c);