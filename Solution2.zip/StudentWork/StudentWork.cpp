#include <iostream>
#include "..\MathLibrary\MathLibrary.hpp"
int main()
{
    std::cout << "Hello World!\n";
}

