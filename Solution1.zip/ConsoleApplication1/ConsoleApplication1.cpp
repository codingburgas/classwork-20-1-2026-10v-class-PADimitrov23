// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "MathLibrary.hpp"

using namespace std;


int main()
{
    float a, b, c;
    cin >> a >> b >> c;

   cout << trianglePerimeter(a, b, c) << endl;
   cout << trianglePlot(a, b, c);
}